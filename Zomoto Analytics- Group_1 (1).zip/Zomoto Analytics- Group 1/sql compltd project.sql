use zomato_sales;

SHOW VARIABLES LIKE 'secure_file_priv';
CREATE TABLE zomato1 (
    RestaurantID INT,
    RestaurantName VARCHAR(255),
    CountryCode INT,
    Country_Name VARCHAR(100),
    City VARCHAR(100),
    Address TEXT,
    Locality VARCHAR(100),
    LocalityVerbose VARCHAR(150),
    Longitude DECIMAL(10,6),
    Latitude DECIMAL(10,6),
    Cuisines TEXT,
    Currency VARCHAR(50),
    Has_Table_booking VARCHAR(10),
    Has_Online_delivery VARCHAR(10),
    Is_delivering_now VARCHAR(10),
    Switch_to_order_menu VARCHAR(10),
    Price_range INT,
    Votes INT,
    Average_Cost_for_two INT,
    Rating DECIMAL(3,2),
    Datekey_Opening DATE,
    Year INT,
    Month_Number INT,
    Month_Name VARCHAR(20),
    Quarter VARCHAR(5),
    YearMonth VARCHAR(10),
    Weakdayno INT,
    Weekdayname VARCHAR(20),
    FinancialMOnth VARCHAR(10),
    Financial_Quarter VARCHAR(10)
);
DESC zomato_cleaned;
SET GLOBAL local_infile = 0;
LOAD DATA INFILE
'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Zomato.csv'
INTO TABLE zomato_sales
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

select * from zomato_cleaned;

SELECT COUNT(*) AS total_rows FROM zomato_cleaned;
SET SQL_SAFE_UPDATES = 0;

DELETE t1 FROM zomato_cleaned t1
INNER JOIN zomato_cleaned t2
WHERE
    t1.restaurantid > t2.restaurantid AND
    t1.restaurantid = t2.restaurantid;

SET SQL_SAFE_UPDATES = 1;

SELECT COUNT(*) AS total_rows FROM zomato_cleaned;
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT RestaurantID) AS unique_rows
FROM zomato_cleaned;
SELECT restaurantid, COUNT(*) AS count_rows
FROM zomato_cleaned
GROUP BY restaurantid
HAVING count_rows > 1;
SET SQL_SAFE_UPDATES = 0;
DELETE t1 FROM zomato t1
INNER JOIN zomato t2
WHERE
    t1.restaurantid > t2.restaurantid
    AND t1.restaurantid = t2.restaurantid;
    
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT restaurantid) AS unique_rows
FROM zomato_cleaned;

CREATE TABLE zomato_backup AS SELECT * FROM zomato_cleaned;
TRUNCATE TABLE zomato_cleaned;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/zomato.csv'
INTO TABLE zomato_cleaned
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

SELECT COUNT(*) AS total_rows FROM zomato_cleaned;
select * from zomato_cleaned;

-- .1 Build a country Map Table

SELECT
    Country_Name AS country,
    Latitude,
    Longitude,
    COUNT(RestaurantID) AS total_restaurants
FROM zomato_cleaned
GROUP BY 
    Country_Name,
    Latitude,
    Longitude;

-- 2. Build a Calendar Table using the Column Datekey

SELECT DISTINCT
    datekey_opening AS Date,

    /* A. Year */
    YEAR(datekey_opening) AS Year,

    /* B. Month Number */
    MONTH(datekey_opening) AS MonthNo,

    /* C. Month Full Name */
    MONTHNAME(datekey_opening) AS MonthFullName,

    /* D. Quarter */
    CONCAT('Q', QUARTER(datekey_opening)) AS Quarter,

    /* E. YearMonth (YYYY-MMM) */
    DATE_FORMAT(datekey_opening, '%Y-%b') AS YearMonth,

    /* F. Weekday Number (Monday = 1) */
    WEEKDAY(datekey_opening) + 1 AS WeekdayNo,

    /* G. Weekday Name */
    DAYNAME(datekey_opening) AS WeekdayName,

    /* H. Financial Month (April = FM1 … March = FM12) */
    CASE
        WHEN MONTH(datekey_opening) >= 4
            THEN CONCAT('FM', MONTH(datekey_opening) - 3)
        ELSE
            CONCAT('FM', MONTH(datekey_opening) + 9)
    END AS FinancialMonth,

    /* I. Financial Quarter */
    CASE
        WHEN MONTH(datekey_opening) BETWEEN 4 AND 6 THEN 'FQ1'
        WHEN MONTH(datekey_opening) BETWEEN 7 AND 9 THEN 'FQ2'
        WHEN MONTH(datekey_opening) BETWEEN 10 AND 12 THEN 'FQ3'
        ELSE 'FQ4'
    END AS FinancialQuarter

FROM zomato_cleaned
ORDER BY Date;


-- 3. Find the Numbers of Resturants based on City and Country.

SELECT
    Country_Name AS country,
    City,
    COUNT(RestaurantID) AS number_of_restaurants
FROM zomato_cleaned
GROUP BY
    Country_Name,
    City
ORDER BY
    country,
    number_of_restaurants DESC;


-- 4. Numbers of Resturants opening based on Year , Quarter , Month
SELECT
    YEAR(datekey_opening) AS year,
    QUARTER(datekey_opening) AS quarter,
    MONTH(datekey_opening) AS month,
    MONTHNAME(datekey_opening) AS month_name,
    COUNT(RestaurantID) AS total_restaurants
FROM zomato_cleaned
GROUP BY
    YEAR(datekey_opening),
    QUARTER(datekey_opening),
    MONTH(datekey_opening),
    MONTHNAME(datekey_opening)
ORDER BY year, quarter, month;

-- 5. Count of Resturants based on Average Ratings

SELECT
    Rating,
    COUNT(RestaurantID) AS restaurant_count
FROM zomato_cleaned
GROUP BY Rating
ORDER BY Rating;

-- 6. Create buckets based on Average Price of reasonable size and find out how many resturants falls in each buckets 
SELECT
    CASE
        WHEN Average_Cost_for_two < 500 THEN 'Low (Below 500)'
        WHEN Average_Cost_for_two BETWEEN 500 AND 1000 THEN 'Medium (500 - 1000)'
        WHEN Average_Cost_for_two BETWEEN 1001 AND 2000 THEN 'High (1001 - 2000)'
        WHEN Average_Cost_for_two BETWEEN 2001 AND 5000 THEN 'Very High (2001 - 5000)'
        ELSE 'Luxury (Above 5000)'
    END AS price_bucket,
    COUNT(RestaurantID) AS restaurant_count
FROM zomato
GROUP BY price_bucket
ORDER BY restaurant_count DESC;

-- 7. Percentage of Resturants based on "Has_Table_booking"

SELECT
    Has_Table_booking,
    COUNT(*) AS total_restaurants,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM zomato_cleaned),
        2
    ) AS percentage
FROM zomato_cleaned
GROUP BY Has_Table_booking;

-- 8. Percentage of Resturants based on "Has_Online_delivery"

SELECT
    Has_Online_delivery,
    COUNT(*) AS restaurant_count,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM zomato_cleaned),
        2
    ) AS percentage
FROM zomato_cleaned
GROUP BY Has_Online_delivery;

